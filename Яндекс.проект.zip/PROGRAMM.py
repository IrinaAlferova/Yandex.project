import pygame
import sys
import os
pygame.init()
clock = pygame.time.Clock();

do=pygame.mixer.Sound(os.path.join("do.wav"))
re=pygame.mixer.Sound(os.path.join("re.wav"))
mi=pygame.mixer.Sound(os.path.join("mi.wav"))
fa=pygame.mixer.Sound(os.path.join("fa.wav"))
sol=pygame.mixer.Sound(os.path.join("sol.wav"))
si=pygame.mixer.Sound(os.path.join("si.wav"))
la=pygame.mixer.Sound(os.path.join("la.wav"))
dodiez=pygame.mixer.Sound(os.path.join("dodiez.wav"))
rediez=pygame.mixer.Sound(os.path.join("rediez.wav"))
fadiez=pygame.mixer.Sound(os.path.join("fadiez.wav"))
soldiez=pygame.mixer.Sound(os.path.join("soldiez.wav"))
ladiez=pygame.mixer.Sound(os.path.join("ladiez.wav"))
doo=pygame.mixer.Sound(os.path.join("doo.wav"))
re2=pygame.mixer.Sound(os.path.join("re2.wav"))
mi2=pygame.mixer.Sound(os.path.join("mi2.wav"))
fa2=pygame.mixer.Sound(os.path.join("fa2.wav"))
sol2=pygame.mixer.Sound(os.path.join("sol2.wav"))
si2=pygame.mixer.Sound(os.path.join("si2.wav"))
la2=pygame.mixer.Sound(os.path.join("la2.wav"))
dodiez2=pygame.mixer.Sound(os.path.join("dodiez2.wav"))
rediez2=pygame.mixer.Sound(os.path.join("rediez2.wav"))
fadiez2=pygame.mixer.Sound(os.path.join("fadiez2.wav"))
soldiez2=pygame.mixer.Sound(os.path.join("soldiez2.wav"))
ladiez2=pygame.mixer.Sound(os.path.join("ladiez2.wav"))
doo2=pygame.mixer.Sound(os.path.join("doo2.wav"))
key = pygame.image.load(os.path.join("key.png"))
key = pygame.transform.scale(key, (100,110))
crs=pygame.image.load(os.path.join('cursor.png'))
crs = pygame.transform.scale(crs, (30,30))
empty_piece=pygame.image.load(os.path.join("NL.png"))
empty_piece_rect=empty_piece.get_rect()
notes=[do,dodiez,re,rediez,mi,fa,fadiez,sol,soldiez,la,ladiez,si,doo,dodiez2,re2,rediez2,mi2,fa2,fadiez2,sol2,soldiez2,la2,ladiez2,si2,doo2]
Notes=[]
key_notes1={pygame.K_q:0,pygame.K_2:1,pygame.K_w:2,pygame.K_3:3,pygame.K_e:4,pygame.K_r:5,pygame.K_5:6,pygame.K_t:7,pygame.K_6:8, pygame.K_y:9,pygame.K_7:10, pygame.K_u:11, pygame.K_i:12,pygame.K_9:13,pygame.K_o:14,pygame.K_0:15,pygame.K_p:16,pygame.K_LEFTBRACKET:17,pygame.K_EQUALS:18,pygame.K_RIGHTBRACKET:19,pygame.K_BACKSPACE:20,pygame.K_BACKSLASH:21, pygame.K_KP_DIVIDE:22,pygame.K_KP7:23,pygame.K_KP8:24}
key_notes={202:0,50:1,195:2,51:3,213:4,203:5,53:6,197:7,54:8, 206:9, 55:10, 199:11, 219:12,57:13,221:14,48:15,218:16,200:17,61:18,223:19,8:20,267:22, 263:23, 264:24,92:21}
black_keys=[1,3,6,8,10,13,15,18,20,22]
class Key:

    def __init__(self,number):
        
        if number==0:
            self.note="do"
            self.number=0
            self.image=pygame.Surface((35,180))
            self.image.fill(pygame.Color("white"))
            self.rect = pygame.Rect(40,300,35,180)
            self.font = pygame.font.Font(None, 25)
            self.rendered_text = self.font.render("q", 1, (255,255,255))
            self.rendered_rect = self.rendered_text.get_rect(x=self.rect.x + 5, y=575-305)  
            self.image_note=pygame.image.load(os.path.join('do.png'))
            self.rect_note=self.image_note.get_rect()
            self.rect2 = pygame.Rect(40+size[0]//2-300,300+size[1]//2-250,35,180)
            self.rendered_rect2 = self.rendered_text.get_rect(x=self.rect2.x + 5, y=575-305+size[1]//2-250)
            
        elif number==1:
            self.note="dodiez"
            self.number=1
            self.image=pygame.Surface((16,110))
            self.image.fill(pygame.Color("black"))
            self.rect = pygame.Rect(72-8,300,16,110)
            self.font = pygame.font.Font(None,25)
            self.rendered_text = self.font.render("2", 1, (255,255,255))
            self.rendered_rect = self.rendered_text.get_rect(x=self.rect.x + 5, y=480-150)  
            self.image_note=pygame.image.load(os.path.join('dodiez.png'))
            self.rect_note=self.image_note.get_rect()
            self.rect2 = pygame.Rect(72-8+size[0]//2-300,300+size[1]//2-250,35,180)
            self.rendered_rect2 = self.rendered_text.get_rect(x=self.rect2.x + 5, y=480-150+size[1]//2-250)            
            
        elif number==2:
            self.note="re"
            self.number=2
            self.image=pygame.Surface((35,180))
            self.image.fill(pygame.Color("white"))
            self.rect = pygame.Rect(75,300,35,180)  
            self.font = pygame.font.Font(None, 25)
            self.rendered_text = self.font.render("w", 1, (255,255,255))
            self.rendered_rect = self.rendered_text.get_rect(x=self.rect.x + 5, y=575-305)     
            self.image_note=pygame.image.load(os.path.join('re.png'))
            self.rect_note=self.image_note.get_rect()    
            self.rect2 = pygame.Rect(75+size[0]//2-300,300+size[1]//2-250,35,180)
            self.rendered_rect2 = self.rendered_text.get_rect(x=self.rect2.x + 5, y=575-305+size[1]//2-250)            
            
        elif number==3:
            self.note="rediez"
            self.number=3
            self.image=pygame.Surface((16,110))
            self.image.fill(pygame.Color("black"))
            self.rect = pygame.Rect(110-3-8,300,16,110) 
            self.font = pygame.font.Font(None,25)
            self.rendered_text = self.font.render("3", 1, (255,255,255))
            self.rendered_rect = self.rendered_text.get_rect(x=self.rect.x + 5, y=480-150)     
            self.image_note=pygame.image.load(os.path.join('rediez.png'))
            self.rect_note=self.image_note.get_rect()   
            self.rect2 = pygame.Rect(110-11+size[0]//2-300,300+size[1]//2-250,35,180)
            self.rendered_rect2 = self.rendered_text.get_rect(x=self.rect2.x + 5, y=480-150+size[1]//2-250)            
            
        elif number==4:
            self.note="mi"
            self.number=4
            self.image=pygame.Surface((35,180))
            self.image.fill(pygame.Color("white"))
            self.rect = pygame.Rect(110,300,35,180) 
            self.font = pygame.font.Font(None, 25)
            self.rendered_text = self.font.render("e", 1, (255,255,255))
            self.rendered_rect = self.rendered_text.get_rect(x=self.rect.x + 5, y=575-305)  
            self.image_note=pygame.image.load(os.path.join('mi.png'))
            self.rect_note=self.image_note.get_rect()
            self.rect2 = pygame.Rect(110+size[0]//2-300,300+size[1]//2-250,35,180)
            self.rendered_rect2 = self.rendered_text.get_rect(x=self.rect2.x + 5, y=575-305+size[1]//2-250)            
            
        elif number==5:
            self.note="fa"
            self.number=5
            self.image=pygame.Surface((35,180))
            self.image.fill(pygame.Color("white"))
            self.rect = pygame.Rect(145,300,35,180) 
            self.font = pygame.font.Font(None, 25)
            self.rendered_text = self.font.render("r", 1, (255,255,255))
            self.rendered_rect = self.rendered_text.get_rect(x=self.rect.x + 5, y=575-305)
            self.image_note=pygame.image.load(os.path.join('fa.png'))
            self.rect_note=self.image_note.get_rect()  
            self.rect2 = pygame.Rect(145+size[0]//2-300,300+size[1]//2-250,35,180)
            self.rendered_rect2 = self.rendered_text.get_rect(x=self.rect2.x + 5, y=575-305+size[1]//2-250)            
            
        elif number==6:
            self.note="fadiez"
            self.number=6
            self.image=pygame.Surface((16,110))
            self.image.fill(pygame.Color("black"))
            self.rect = pygame.Rect(180-3-8,300,16,110)
            self.font = pygame.font.Font(None,25)
            self.rendered_text = self.font.render("5", 1, (255,255,255))
            self.rendered_rect = self.rendered_text.get_rect(x=self.rect.x + 5, y=480-150)    
            self.image_note=pygame.image.load(os.path.join('fadiez.png'))
            self.rect_note=self.image_note.get_rect()  
            self.rect2 = pygame.Rect(180-11+size[0]//2-300,300+size[1]//2-250,35,180)
            self.rendered_rect2 = self.rendered_text.get_rect(x=self.rect2.x + 5, y=480-150+size[1]//2-250)            
            
        elif number==7:
            self.note="sol"
            self.number=7
            self.image=pygame.Surface((35,180))
            self.image.fill(pygame.Color("white"))
            self.rect = pygame.Rect(180,300,35,180)
            self.font = pygame.font.Font(None, 35)
            self.rendered_text = self.font.render("t", 1, (255,255,255))
            self.rendered_rect = self.rendered_text.get_rect(x=self.rect.x + 5, y=575-305)       
            self.image_note=pygame.image.load(os.path.join('sol.png'))
            self.rect_note=self.image_note.get_rect()    
            self.rect2 = pygame.Rect(180+size[0]//2-300,300+size[1]//2-250,35,180)
            self.rendered_rect2 = self.rendered_text.get_rect(x=self.rect2.x + 5, y=575-305+size[1]//2-250)            
            
        elif number==8:
            self.note="soldiez"
            self.number=8
            self.image=pygame.Surface((16,110))
            self.image.fill(pygame.Color("black"))
            self.rect = pygame.Rect(215-11,300,16,110)
            self.font = pygame.font.Font(None,25)
            self.rendered_text = self.font.render("6", 1, (255,255,255))
            self.rendered_rect = self.rendered_text.get_rect(x=self.rect.x + 5, y=480-150) 
            self.image_note=pygame.image.load(os.path.join('soldiez.png'))
            self.rect_note=self.image_note.get_rect() 
            self.rect2 = pygame.Rect(215-11+size[0]//2-300,300+size[1]//2-250,35,180)
            self.rendered_rect2 = self.rendered_text.get_rect(x=self.rect2.x + 5, y=480-150+size[1]//2-250)            
            
        elif number==9:
            self.note="la"
            self.number=9
            self.image=pygame.Surface((35,180))
            self.image.fill(pygame.Color("white"))
            self.rect = pygame.Rect(215,300,35,180)   
            self.font = pygame.font.Font(None,25)
            self.rendered_text = self.font.render("y", 1, (255,255,255))
            self.rendered_rect = self.rendered_text.get_rect(x=self.rect.x + 5, y=575-305)   
            self.image_note=pygame.image.load(os.path.join('la.png'))
            self.rect_note=self.image_note.get_rect()
            self.rect2 = pygame.Rect(215+size[0]//2-300,300+size[1]//2-250,35,180)
            self.rendered_rect2 = self.rendered_text.get_rect(x=self.rect2.x + 5, y=575-305+size[1]//2-250)            
            
        elif number==10:
            self.note="ladiez"
            self.number=10
            self.image=pygame.Surface((16,110))
            self.image.fill(pygame.Color("black"))
            self.rect = pygame.Rect(250-11,300,16,110) 
            self.font = pygame.font.Font(None,25)
            self.rendered_text = self.font.render("7", 1, (255,255,255))
            self.rendered_rect = self.rendered_text.get_rect(x=self.rect.x + 5, y=480-150)  
            self.image_note=pygame.image.load(os.path.join('ladiez.png'))
            self.rect_note=self.image_note.get_rect()
            self.rect2 = pygame.Rect(250-11+size[0]//2-300,300+size[1]//2-250,35,180)
            self.rendered_rect2 = self.rendered_text.get_rect(x=self.rect2.x + 5, y=480-150+size[1]//2-250)            
            
        elif number==11:
            self.note="si"
            self.number=11
            self.image=pygame.Surface((35,180))
            self.image.fill(pygame.Color("white"))
            self.rect = pygame.Rect(250,300,35,180)  
            self.font = pygame.font.Font(None, 25)
            self.rendered_text = self.font.render("u", 1, (255,255,255))
            self.rendered_rect = self.rendered_text.get_rect(x=self.rect.x + 5, y=575-305)   
            self.image_note=pygame.image.load(os.path.join('si.png'))
            self.rect_note=self.image_note.get_rect()  
            self.rect2 = pygame.Rect(250+size[0]//2-300,300+size[1]//2-250,35,180)
            self.rendered_rect2 = self.rendered_text.get_rect(x=self.rect2.x + 5, y=575-305+size[1]//2-250)            

        elif number==12:
            self.note="doo"
            self.number=12
            self.image=pygame.Surface((35,180))
            self.image.fill(pygame.Color("white"))
            self.rect = pygame.Rect(285,300,35,180) 
            self.font = pygame.font.Font(None, 25)
            self.rendered_text = self.font.render("i", 1,(255,255,255))
            self.rendered_rect = self.rendered_text.get_rect(x=self.rect.x + 5, y=575-305)   
            self.image_note=pygame.image.load(os.path.join('doo.png'))
            self.rect_note=self.image_note.get_rect()
            self.rect2 = pygame.Rect(285+size[0]//2-300,300+size[1]//2-250,35,180)
            self.rendered_rect2 = self.rendered_text.get_rect(x=self.rect2.x + 5, y=575-305+size[1]//2-250)            
            
        elif number==13:
            self.note="dodiez2"
            self.number=13
            self.image=pygame.Surface((16,110))
            self.image.fill(pygame.Color("black"))
            self.rect = pygame.Rect(320-11,300,16,110)
            self.font = pygame.font.Font(None,25)
            self.rendered_text = self.font.render("9", 1, (255,255,255))
            self.rendered_rect = self.rendered_text.get_rect(x=self.rect.x + 5, y=480-150)  
            self.image_note=pygame.image.load(os.path.join('dodiez2.png'))
            self.rect_note=self.image_note.get_rect() 
            self.rect2 = pygame.Rect(320-11+size[0]//2-300,300+size[1]//2-250,35,180)
            self.rendered_rect2 = self.rendered_text.get_rect(x=self.rect2.x + 5, y=480-150+size[1]//2-250)            
            
        elif number==14:
            self.note="re2"
            self.number=14
            self.image=pygame.Surface((35,180))
            self.image.fill(pygame.Color("white"))
            self.rect = pygame.Rect(320,300,35,180)  
            self.font = pygame.font.Font(None, 25)
            self.rendered_text = self.font.render("o", 1, (255,255,255))
            self.rendered_rect = self.rendered_text.get_rect(x=self.rect.x + 5, y=575-305)    
            self.image_note=pygame.image.load(os.path.join('re2.png'))
            self.rect_note=self.image_note.get_rect()
            self.rect2 = pygame.Rect(320+size[0]//2-300,300+size[1]//2-250,35,180)
            self.rendered_rect2 = self.rendered_text.get_rect(x=self.rect2.x + 5, y=575-305+size[1]//2-250)            
            
        elif number==15:
            self.note="rediez2"
            self.number=15
            self.image=pygame.Surface((16,110))
            self.image.fill(pygame.Color("black"))
            self.rect = pygame.Rect(320+35-11,300,16,110) 
            self.font = pygame.font.Font(None,25)
            self.rendered_text = self.font.render("0", 1, (255,255,255))
            self.rendered_rect = self.rendered_text.get_rect(x=self.rect.x + 5, y=480-150) 
            self.image_note=pygame.image.load(os.path.join('rediez2.png'))
            self.rect_note=self.image_note.get_rect()
            self.rect2 = pygame.Rect(320+35-11+size[0]//2-300,300+size[1]//2-250,35,180)
            self.rendered_rect2 = self.rendered_text.get_rect(x=self.rect2.x + 5, y=480-150+size[1]//2-250)            
            
        elif number==16:
            self.note="mi2"
            self.number=16
            self.image=pygame.Surface((35,180))
            self.image.fill(pygame.Color("white"))
            self.rect = pygame.Rect(320+35,300,35,180) 
            self.font = pygame.font.Font(None, 25)
            self.rendered_text = self.font.render("p", 1, (255,255,255))
            self.rendered_rect = self.rendered_text.get_rect(x=self.rect.x + 5, y=575-305)  
            self.image_note=pygame.image.load(os.path.join('mi2.png'))
            self.rect_note=self.image_note.get_rect() 
            self.rect2 = pygame.Rect(320+35+size[0]//2-300,300+size[1]//2-250,35,180)
            self.rendered_rect2 = self.rendered_text.get_rect(x=self.rect2.x + 5, y=575-305+size[1]//2-250)            
            
        elif number==17:
            self.note="fa2"
            self.number=17
            self.image=pygame.Surface((35,180))
            self.image.fill(pygame.Color("white"))
            self.rect = pygame.Rect(320+70,300,35,180) 
            self.font = pygame.font.Font(None, 25)
            self.rendered_text = self.font.render("[", 1, (255,255,255))
            self.rendered_rect = self.rendered_text.get_rect(x=self.rect.x + 5, y=575-305)  
            self.image_note=pygame.image.load(os.path.join('fa2.png'))
            self.rect_note=self.image_note.get_rect()
            self.rect2 = pygame.Rect(320+70+size[0]//2-300,300+size[1]//2-250,35,180)
            self.rendered_rect2 = self.rendered_text.get_rect(x=self.rect2.x + 5, y=575-305+size[1]//2-250)            
            
        elif number==18:
            self.note="fadiez2"
            self.number=18
            self.image=pygame.Surface((16,110))
            self.image.fill(pygame.Color("black"))
            self.rect = pygame.Rect(390+35-11,300,16,110)
            self.font = pygame.font.Font(None,25)
            self.rendered_text = self.font.render("=", 1, (255,255,255))
            self.rendered_rect = self.rendered_text.get_rect(x=self.rect.x + 5, y=480-150)
            self.image_note=pygame.image.load(os.path.join('fadiez2.png'))
            self.rect_note=self.image_note.get_rect()
            self.rect2 = pygame.Rect(390+35-11+size[0]//2-300,300+size[1]//2-250,35,180)
            self.rendered_rect2 = self.rendered_text.get_rect(x=self.rect2.x + 5, y=480-150+size[1]//2-250)            
            
        elif number==19:
            self.note="sol2"
            self.number=19
            self.image=pygame.Surface((35,180))
            self.image.fill(pygame.Color("white"))
            self.rect = pygame.Rect(390+35,300,35,180)
            self.font = pygame.font.Font(None, 25)
            self.rendered_text = self.font.render("]", 1, (255,255,255))
            self.rendered_rect = self.rendered_text.get_rect(x=self.rect.x + 5, y=575-305)  
            self.image_note=pygame.image.load(os.path.join('sol2.png'))
            self.rect_note=self.image_note.get_rect()    
            self.rect2 = pygame.Rect(390+35+size[0]//2-300,300+size[1]//2-250,35,180)
            self.rendered_rect2 = self.rendered_text.get_rect(x=self.rect2.x + 5, y=575-305+size[1]//2-250)            
            
        elif number==20:
            self.note="soldiez2"
            self.number=20
            self.image=pygame.Surface((16,110))
            self.image.fill(pygame.Color("black"))
            self.rect = pygame.Rect(390+70-11,300,16,110)
            self.font = pygame.font.Font(None,20)
            self.rendered_text = self.font.render("<-", 1, (255,255,255))
            self.rendered_rect = self.rendered_text.get_rect(x=self.rect.x + 2, y=480-150)
            self.image_note=pygame.image.load(os.path.join('soldiez2.png'))
            self.rect_note=self.image_note.get_rect() 
            self.rect2 = pygame.Rect(390+70-11+size[0]//2-300,300+size[1]//2-250,35,180)
            self.rendered_rect2 = self.rendered_text.get_rect(x=self.rect2.x + 5, y=480-150+size[1]//2-250)            
            
        elif number==21:
            self.note="la2"
            self.number=21
            self.image=pygame.Surface((35,180))
            self.image.fill(pygame.Color("white"))
            self.rect = pygame.Rect(390+70,300,35,180)   
            self.font = pygame.font.Font(None, 25)
            self.rendered_text = self.font.render("\|/", 1, (255,255,255))
            self.rendered_rect = self.rendered_text.get_rect(x=self.rect.x + 5, y=575-305) 
            self.image_note=pygame.image.load(os.path.join('la2.png'))
            self.rect_note=self.image_note.get_rect()
            self.rect2 = pygame.Rect(390+70+size[0]//2-300,300+size[1]//2-250,35,180)
            self.rendered_rect2 = self.rendered_text.get_rect(x=self.rect2.x + 5, y=575-305+size[1]//2-250)            
            
        elif number==22:
            self.note="ladiez2"
            self.number=22
            self.image=pygame.Surface((16,110))
            self.image.fill(pygame.Color("black"))
            self.rect = pygame.Rect(460+35-11,300,16,110) 
            self.font = pygame.font.Font(None,25)
            self.rendered_text = self.font.render("/", 1, (255,255,255))
            self.rendered_rect = self.rendered_text.get_rect(x=self.rect.x+5 , y=480-150)   
            self.image_note=pygame.image.load(os.path.join('ladiez2.png'))
            self.rect_note=self.image_note.get_rect()
            self.rect2 = pygame.Rect(460+35-11+size[0]//2-300,300+size[1]//2-250,35,180)
            self.rendered_rect2 = self.rendered_text.get_rect(x=self.rect2.x + 5, y=480-150+size[1]//2-250)            
            
        elif number==23:
            self.note="si2"
            self.number=23
            self.image=pygame.Surface((35,180))
            self.image.fill(pygame.Color("white"))
            self.rect = pygame.Rect(460+35,300,35,180)  
            self.font = pygame.font.Font(None, 25)
            self.rendered_text = self.font.render("7", 1, (255,255,255))
            self.rendered_rect = self.rendered_text.get_rect(x=self.rect.x + 5, y=575-305)  
            self.image_note=pygame.image.load(os.path.join('si2.png'))
            self.rect_note=self.image_note.get_rect() 
            self.rect2 = pygame.Rect(460+35+size[0]//2-300,300+size[1]//2-250,35,180)
            self.rendered_rect2 = self.rendered_text.get_rect(x=self.rect2.x + 5, y=575-305+size[1]//2-250)            
            
        elif number==24:
            self.note="doo2"
            self.number=24
            self.image=pygame.Surface((35,180))
            self.image.fill(pygame.Color("white"))
            self.rect = pygame.Rect(460+70,300,35,180) 
            self.font = pygame.font.Font(None, 25)
            self.rendered_text = self.font.render("8", 1, (255,255,255))
            self.rendered_rect = self.rendered_text.get_rect(x=self.rect.x + 5, y=575-305)  
            self.image_note=pygame.image.load(os.path.join('doo2.png'))
            self.rect_note=self.image_note.get_rect() 
            self.rect2 = pygame.Rect(460+70+size[0]//2-300,300+size[1]//2-250,35,180)
            self.rendered_rect2 = self.rendered_text.get_rect(x=self.rect2.x + 5, y=575-305+size[1]//2-250)            
            
    def draw(self,surf):
  
        if self.number != 1 and self.number != 3 and self.number != 6 and self.number != 8 and self.number != 10 and self.number != 13 and self.number != 15 and self.number != 18 and self.number != 20 and self.number != 22:
            border=pygame.Surface((45,210))
            border.fill(pygame.Color("black"))
            surf.blit(border, (self.rect.x-5,self.rect.y,100,180))
        surf.blit(self.image, self.rect)
        surf.blit(self.rendered_text, self.rendered_rect)
        
    def draw2(self,surf):
  
        if self.number != 1 and self.number != 3 and self.number != 6 and self.number != 8 and self.number != 10 and self.number != 13 and self.number != 15 and self.number != 18 and self.number != 20 and self.number != 22:
            border=pygame.Surface((45,210))
            border.fill(pygame.Color("black"))
            surf.blit(border, (self.rect.x-5+size[0]//2-300,self.rect.y+size[1]//2-250,100,180))
        surf.blit(self.image, self.rect2)
        surf.blit(self.rendered_text, self.rendered_rect2)    
        
    def KEYDOWN(self,surf,previous,count):
        
        if self.number != 1 and self.number != 3 and self.number != 6 and self.number != 8 and self.number != 10 and self.number != 13 and self.number != 15 and self.number != 18 and self.number != 20 and self.number != 22:
            self.image=pygame.Surface((30,195))
            self.image.fill((255,255,255))
            surf.blit(self.image, self.rect)
        else:
            self.image=pygame.Surface((16,120))
            self.image.fill((0,0,0))
            surf.blit(self.image, self.rect)   
        pygame.display.flip()
        notes[previous].play(2)
        notes[previous].stop()
        notes[self.number].play()
        if self.rect_note.width*count+100+10<590:
            self.rect_note.x=self.rect_note.width*count+100+10
            self.rect_note.y=2
        else:
            self.rect_note.x=self.rect_note.width*count+100+10-590
            self.rect_note.y=152
        width= self.rect_note.x
        height=self.rect_note.y
        Notes.append((self.image_note, (width,height)))
        
    def KEYUP(self,surf):
        
        if self.number != 1 and self.number != 3 and self.number != 6 and self.number != 8 and self.number != 10 and self.number != 13 and self.number != 15 and self.number != 18 and self.number != 20 and self.number != 22:
            self.image=pygame.Surface((35,180))
            self.image.fill((255,255,255))
            surf.blit(self.image, self.rect)
        else:
            self.image=pygame.Surface((16,110))
            self.image.fill((0,0,0))
            surf.blit(self.image, self.rect)
    def KEYUP2(self,surf):
        
        if self.number != 1 and self.number != 3 and self.number != 6 and self.number != 8 and self.number != 10 and self.number != 13 and self.number != 15 and self.number != 18 and self.number != 20 and self.number != 22:
            self.image=pygame.Surface((35,180))
            self.image.fill((255,255,255))
            surf.blit(self.image, self.rect2)
        else:
            self.image=pygame.Surface((16,110))
            self.image.fill((0,0,0))
            surf.blit(self.image, self.rect2)            
            
    def KEYDOWN2(self,surf,previous,count):
        
        if self.number != 1 and self.number != 3 and self.number != 6 and self.number != 8 and self.number != 10 and self.number != 13 and self.number != 15 and self.number != 18 and self.number != 20 and self.number != 22:
            self.image=pygame.Surface((30,195))
            self.image.fill((255,255,255))
            surf.blit(self.image, self.rect2)
        else:
            self.image=pygame.Surface((16,120))
            self.image.fill((0,0,0))
            surf.blit(self.image, self.rect2)   
        pygame.display.flip()
        notes[previous].play(2)
        notes[previous].stop()
        notes[self.number].play()
        if self.rect_note.width*count+100+10<590:
            self.rect_note.x=self.rect_note.width*count+100+10
            self.rect_note.y=2
        else:
            self.rect_note.x=self.rect_note.width*count+100+10-590
            self.rect_note.y=152
        width= self.rect_note.x
        height=self.rect_note.y
        Notes.append((self.image_note, (width,height)))
        
all_keys = []
previous=0
count=0
F_FULL=False
infos = pygame.display.Info()
size = (infos.current_w, infos.current_h)  
for i in range(25):
    all_keys.append(Key(i))
screen = pygame.display.set_mode((600,500),pygame.RESIZABLE) 
cursor_pos=None
running=True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running=False
        if event.type == pygame.MOUSEMOTION:
            cursor_pos = event.pos        
        if event.type==pygame.KEYDOWN:
            try:
                if not F_FULL:
                    all_keys[key_notes1[event.key]].KEYDOWN(screen,previous,count)
                else:
                    all_keys[key_notes1[event.key]].KEYDOWN2(screen,previous,count)
                previous=key_notes1[event.key]
                count=count+1
            except KeyError:
                if event.key==pygame.K_ESCAPE:
                    if F_FULL:
                        pygame.display.set_mode((600,500),pygame.RESIZABLE)
                    F_FULL=False
                elif event.key==pygame.K_LALT:
                    FALT=True
                if event.key==pygame.K_F12 and FALT:
                    pygame.display.set_mode(size,pygame.FULLSCREEN)
                    F_FULL=True       
        if event.type==pygame.KEYUP:
            try:
                if not F_FULL:
                    all_keys[key_notes1[event.key]].KEYUP(screen) 
                else:
                    all_keys[key_notes1[event.key]].KEYUP2(screen)
            except KeyError:
                if event.key==pygame.K_NUMLOCK:
                    try:
                        Notes.pop()
                        count-=1
                    except Exception:
                        pass
                if event.key==pygame.K_LALT:
                    FALT=False
    pygame.mouse.set_visible(False)
    screen.fill((0,0,125))
    if cursor_pos and pygame.mouse.get_focused():
        screen.blit(crs,cursor_pos) 
    if F_FULL:
        pygame.draw.line(screen, (255,255,255),(size[0]//2-305,size[1]//2-300),(size[0]//2+305,size[1]//2-300),5)
        pygame.draw.line(screen, (255,255,255),(size[0]//2-305,270+size[1]//2),(size[0]//2+305,270+size[1]//2),5)
        pygame.draw.line(screen, (255,255,255),(size[0]//2-305,size[1]//2-300),(size[0]//2-305,size[1]//2+270),5)
        pygame.draw.line(screen, (255,255,255),(size[0]//2+305,size[1]//2-300),(size[0]//2+305,size[1]//2+270),5)
        for i in range(5):
            pygame.draw.line(screen, (255,255,255),(size[0]//2-300,50+size[1]//2-300+i*10),(size[0]//2+300,50+size[1]//2-300+i*10))  
        for i in range(5):
            pygame.draw.line(screen, (255,255,255),(size[0]//2-300,200+size[1]//2-300+i*10),(size[0]//2+300,200+size[1]//2-300+i*10))
        screen.blit(key,(size[0]//2-300,5+size[1]//2-300))
        for i in range(len(all_keys)):
            all_keys[i].draw2(screen) 
        for i in black_keys:
            all_keys[i].draw2(screen)
        for i in Notes:
            if i[1][0]+size[0]//2-300<=size[0]//2+300:
                screen.blit(i[0],(i[1][0]+size[0]//2-300,i[1][1]+size[1]//2-300))        
    else:
        for i in range(5):
            pygame.draw.line(screen, (255,255,255),(0,50+i*10),(600,50+i*10))
        for i in range(5):
            pygame.draw.line(screen, (255,255,255),(0,200+i*10),(600,200+i*10)) 
        screen.blit(key,(0,5))
        for i in range(len(all_keys)):
            all_keys[i].draw(screen)
        for i in black_keys:
            all_keys[i].draw(screen) 
        for i in Notes:
            screen.blit(i[0],i[1])
    pygame.display.update()
    
pygame.quit()